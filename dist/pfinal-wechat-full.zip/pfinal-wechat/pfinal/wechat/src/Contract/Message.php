<?php

namespace PFinal\Wechat\Contract;

interface Message
{
    /**
     * @return string
     */
    public function type();
}