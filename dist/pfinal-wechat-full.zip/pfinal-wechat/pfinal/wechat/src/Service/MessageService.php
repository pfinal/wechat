<?php

namespace PFinal\Wechat\Service;

use PFinal\Wechat\Contract\MassMessage;
use PFinal\Wechat\Contract\SendMessage;
use PFinal\Wechat\WechatException;

class MessageService extends BaseService
{
    /**
     * 客服消息接口，主动给粉丝发消息。当用户和公众号产生特定动作的交互的48小时内有效。
     * @param $openid
     * @param $message
     * @param null $account 客服帐号(显示客服自定义头像)
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function send($openid, SendMessage $message, $account = null)
    {
        $data = $message->jsonData();
        $type = $message->type();

        $message = array(
            'touser' => $openid,
            'msgtype' => $type,
        );

        $data = array_merge($message, $data);

        if ($account != null) {
            $data['customservice'] = array('kf_account' => $account);
        }

        $url = 'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=ACCESS_TOKEN';

        return parent::request($url, $data);
    }

    /**
     * 高级群发 根据分组进行群发 【订阅号与服务号认证后均可用】
     * 对于认证订阅号，群发接口每天可成功调用1次，此次群发可选择发送给全部用户或某个分组；
     * 对于认证服务号虽然开发者使用高级群发接口的每日调用限制为100次，但是用户每月只能接收4条，无论在公众平台网站上，
     * 还是使用接口群发，用户每月只能接收4条群发消息，多于4条的群发将对该用户发送失败；
     * 具备微信支付权限的公众号，在使用群发接口上传、群发图文消息类型时，可使用<a>标签加入外链；
     * 可以使用预览接口校对消息样式和排版，通过预览接口可发送编辑好的消息给指定用户校验效果。
     *
     * 关于群发时使用is_to_all为true使其进入公众号在微信客户端的历史消息列表：
     * 1、使用is_to_all为true且成功群发，会使得此次群发进入历史消息列表。2、为防止异常，认证订阅号在一天内，只能使用is_to_all为true进行群发一次，或者在公众平台官网群发（不管本次群发是对全体还是对某个分组）一次。以避免一天内有2条群发进入历史消息列表。
     * 3、类似地，服务号在一个月内，使用is_to_all为true群发的次数，加上公众平台官网群发（不管本次群发是对全体还是对某个分组）的次数，最多只能是4次。
     * 4、设置is_to_all为false时是可以多次群发的，但每个用户只会收到最多4条，且这些群发不会进入历史消息列表。
     *
     * @param int $groupId
     * @param string $mediaId 媒体id,如果发送文字，则此参数为需要发送的字符串
     * @param $type
     *      text
     *      mpnews 图文消息
     *      voice
     *      image
     *      wxcard
     *      mpvideo 视频 此处视频的media_id需通过 self::convertMediaIdForSendAll() 方法转换得到
     *
     * @param bool $is_to_all
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function sendAll($groupId, MassMessage $message, $is_to_all = false)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token=ACCESS_TOKEN';
        $data = array(
            'filter' => array('is_to_all' => $is_to_all, 'group_id' => $groupId),
        );

        $data = array_merge($data, $message->jsonData());
        $data['msgtype'] = $message->type();

        return parent::request($url, $data);
    }

    /**
     * 根据OpenID列表群发
     * @param array $openids OpenID最少2个，最多10000个
     * @param MassMessage $message
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function sendAllWithOpenids(array $openids, MassMessage $message)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token=ACCESS_TOKEN';
        $data = array(
            'touser' => $openids,
        );
        $data = array_merge($data, $message->jsonData());
        $data['msgtype'] = $message->type();

        return parent::request($url, $data);

    }

    /**
     * 删除群发
     * @param $msgId
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function delete($msgId)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/delete?access_token=ACCESS_TOKEN';
        return parent::request($url, array('msg_id' => $msgId));
    }

    /**
     * 预览(发给某个openid)
     * @param $openid
     * @param MassMessage $message
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function previewWithOpenid($openid, MassMessage $message)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token=ACCESS_TOKEN';

        $data = array(
            'touser' => $openid,
        );

        $data = array_merge($data, $message->jsonData());
        $data['msgtype'] = $message->type();

        return parent::request($url, $data);
    }

    /**
     * 预览(发给某个微信号)
     * @param $wxname
     * @param MassMessage $message
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function previewWithWxname($wxname, MassMessage $message)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token=ACCESS_TOKEN';
        $data = array(
            'towxname' => $wxname,
        );

        $data = array_merge($data, $message->jsonData());
        $data['msgtype'] = $message->type();

        return parent::request($url, $data);
    }

    /**
     * 查询群发消息发送状态
     * @param $msgId
     * @return array
     * @throws WechatException
     * @throws \Exception
     */
    public static function status($msgId)
    {
        $url = 'https://api.weixin.qq.com/cgi-bin/message/mass/get?access_token=ACCESS_TOKEN';
        return parent::request($url, array('msg_id' => $msgId));
    }

}