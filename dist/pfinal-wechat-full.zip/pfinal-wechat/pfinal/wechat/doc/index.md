# 微信 公众平台(开放平台)SDK

## 官方文档和工具

* http://mp.weixin.qq.com/wiki
* http://mp.weixin.qq.com/debug
* Chrome DevTools
* PC版微信


## 接入

## 消息 (Message)

* 接收微信服务器推送消息和事件 (Receive)
* 被动响应消息 (ReplyMessage)
* 主动发送消息 (SendMessage)
* 群发消息 (MassMessage)

