<?php

namespace PFinal\Wechat;

/**
 * 微信开放平台Api
 * https://open.weixin.qq.com
 *
 * @author  Zou Yiliang
 * @since   1.0
 */
class OpenApi extends Api
{

}
