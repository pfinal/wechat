<?php

namespace PFinal\Wechat;

class WechatException extends \Exception
{

}