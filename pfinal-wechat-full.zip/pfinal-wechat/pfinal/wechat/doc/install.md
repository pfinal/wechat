# 安装


## 环境要求

* PHP >= 5.4
* PHP cURL扩展

## 安装

* 使用 [composer](http://getcomposer.org/)

	```
	$ composer require pfinal/wechat
	```

* 如果你的项目没有使用composer，请 [点击这里](https://github.com/pfinal/wechat/raw/master/dist/pfinal-wechat-full.zip) 下载最新`pfinal/wechat`完整源代码并解压到pfinal-wechat目录



